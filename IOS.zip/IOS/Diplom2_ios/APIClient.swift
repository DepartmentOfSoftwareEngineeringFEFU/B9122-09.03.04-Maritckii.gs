import Foundation

class APIClient {
    static let shared = APIClient()
    let baseURL = URL(string: "http://192.168.0.104:8000")!
    private init() {}

    func login(login: String, password: String) async throws -> TokenResponse {
        let url = baseURL.appendingPathComponent("/api/auth/login")
        var req = URLRequest(url: url)
        req.httpMethod = "POST"
        req.setValue("application/json", forHTTPHeaderField: "Content-Type")
        req.httpBody = try JSONEncoder().encode(LoginRequest(login: login, password: password))
        let (data, _) = try await URLSession.shared.data(for: req)
        let tokenResponse = try JSONDecoder().decode(TokenResponse.self, from: data)
        UserDefaults.standard.set(tokenResponse.accessToken, forKey: "jwt_token")
        return tokenResponse
    }

    func fetchOrders() async throws -> [OrderSummary] {
        let url = baseURL.appendingPathComponent("/api/orders/")
        var req = URLRequest(url: url)
        req.httpMethod = "GET"
        addAuthHeaders(to: &req)
        let (data, _) = try await URLSession.shared.data(for: req)
        return try JSONDecoder().decode([OrderSummary].self, from: data)
    }

    func fetchOrderDetails(orderID: String) async throws -> OrderDetails {
        let url = baseURL.appendingPathComponent("/api/orders/\(orderID)")
        var req = URLRequest(url: url)
        req.httpMethod = "GET"
        addAuthHeaders(to: &req)
        let (data, _) = try await URLSession.shared.data(for: req)
        return try JSONDecoder().decode(OrderDetails.self, from: data)
    }

    func buildRoute(orderID: String) async throws -> RouteResponse {
        let url = baseURL.appendingPathComponent("/api/routes/build/\(orderID)")
        var req = URLRequest(url: url)
        req.httpMethod = "POST"
        addAuthHeaders(to: &req)
        let (data, _) = try await URLSession.shared.data(for: req)
        return try JSONDecoder().decode(RouteResponse.self, from: data)
    }

    func updateOrderStatus(orderID: String, status: String) async throws {
        let url = baseURL.appendingPathComponent("/api/orders/\(orderID)/status")
        var req = URLRequest(url: url)
        req.httpMethod = "POST"
        req.setValue("application/json", forHTTPHeaderField: "Content-Type")
        let body = ["status": status]
        req.httpBody = try JSONEncoder().encode(body)
        addAuthHeaders(to: &req)
        let (data, response) = try await URLSession.shared.data(for: req)
        try validateResponse(response, data: data)
    }

    func verifyScan(orderID: String, barcode: String) async throws -> ScanResponse {
        let url = baseURL.appendingPathComponent("/api/scans/verify/\(orderID)")
        var req = URLRequest(url: url)
        req.httpMethod = "POST"
        req.setValue("application/json", forHTTPHeaderField: "Content-Type")
        addAuthHeaders(to: &req)
        let body = ["barcode": barcode]
        req.httpBody = try JSONEncoder().encode(body)
        let (data, _) = try await URLSession.shared.data(for: req)
        return try JSONDecoder().decode(ScanResponse.self, from: data)
    }

    private func validateResponse(_ response: URLResponse, data: Data) throws {
        guard let httpResponse = response as? HTTPURLResponse else {
            throw NSError(domain: "API", code: -1, userInfo: [NSLocalizedDescriptionKey: "Неверный ответ сервера"])
        }
        guard (200..<300).contains(httpResponse.statusCode) else {
            let body = String(data: data, encoding: .utf8) ?? ""
            throw NSError(domain: "API", code: httpResponse.statusCode, userInfo: [NSLocalizedDescriptionKey: "HTTP \(httpResponse.statusCode): \(body)"])
        }
    }

    private func addAuthHeaders(to req: inout URLRequest) {
        if let token = UserDefaults.standard.string(forKey: "jwt_token") {
            req.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
        }
    }

    func updateOrderProgress(orderID: String, progress: Double) async throws {
        let url = baseURL.appendingPathComponent("/api/orders/\(orderID)/status")
        var req = URLRequest(url: url)
        req.httpMethod = "POST"
        req.setValue("application/json", forHTTPHeaderField: "Content-Type")
        let body: [String: Any] = ["status": "in_progress", "progress": progress]
        req.httpBody = try JSONSerialization.data(withJSONObject: body)
        addAuthHeaders(to: &req)
        let (data, response) = try await URLSession.shared.data(for: req)
        try validateResponse(response, data: data)
    }
}
