import Foundation
import Combine

class AuthManager: ObservableObject {
    @Published var isLoggedIn: Bool

    init() {
        self.isLoggedIn = UserDefaults.standard.string(forKey: "jwt_token") != nil
    }

    func setToken(_ token: String) {
        UserDefaults.standard.set(token, forKey: "jwt_token")
        isLoggedIn = true
    }

    func logout() {
        UserDefaults.standard.removeObject(forKey: "jwt_token")
        isLoggedIn = false
    }
}
