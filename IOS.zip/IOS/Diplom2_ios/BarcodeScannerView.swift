import SwiftUI
import AVFoundation

struct BarcodeScannerView: UIViewControllerRepresentable {
    let onScanned: (String) -> Void
    let onCancel: () -> Void

    func makeUIViewController(context: Context) -> ScannerViewController {
        let vc = ScannerViewController()
        vc.onCodeScanned = { code in
            DispatchQueue.main.async {
                vc.dismiss(animated: true) { self.onScanned(code) }
            }
        }
        vc.onCancelTapped = {
            DispatchQueue.main.async {
                vc.dismiss(animated: true) { self.onCancel() }
            }
        }
        return vc
    }

    func updateUIViewController(_ uiViewController: ScannerViewController, context: Context) {}
}

final class ScannerViewController: UIViewController, AVCaptureMetadataOutputObjectsDelegate {
    var captureSession: AVCaptureSession!
    var previewLayer: AVCaptureVideoPreviewLayer!
    var onCodeScanned: ((String) -> Void)?
    var onCancelTapped: (() -> Void)?
    var isScanning = false
    private let scanAreaRatio = CGRect(x: 0.1, y: 0.35, width: 0.8, height: 0.3)

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .black
        setupCamera()
    }

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        previewLayer?.frame = view.layer.bounds
        setupOverlayIfNeeded()
    }

    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        if captureSession?.isRunning == true { captureSession.stopRunning() }
    }

    private func setupCamera() {
        captureSession = AVCaptureSession()
        captureSession.sessionPreset = .high
        guard let videoDevice = AVCaptureDevice.default(for: .video),
              let videoInput = try? AVCaptureDeviceInput(device: videoDevice),
              captureSession.canAddInput(videoInput) else {
            showAlert("Ошибка", "Не удалось получить доступ к камере")
            return
        }
        captureSession.addInput(videoInput)
        let metadataOutput = AVCaptureMetadataOutput()
        guard captureSession.canAddOutput(metadataOutput) else {
            showAlert("Ошибка", "Не удалось настроить камеру")
            return
        }
        captureSession.addOutput(metadataOutput)
        metadataOutput.setMetadataObjectsDelegate(self, queue: DispatchQueue.main)
        metadataOutput.metadataObjectTypes = [.ean8, .ean13, .code128, .qr]
        metadataOutput.rectOfInterest = scanAreaRatio
        previewLayer = AVCaptureVideoPreviewLayer(session: captureSession)
        previewLayer.frame = view.layer.bounds
        previewLayer.videoGravity = .resizeAspectFill
        view.layer.addSublayer(previewLayer)
        captureSession.startRunning()
    }

    private var overlayAdded = false
    private func setupOverlayIfNeeded() {
        guard !overlayAdded else { return }
        overlayAdded = true
        let bounds = view.bounds
        let overlay = UIView(frame: bounds)
        overlay.backgroundColor = UIColor.black.withAlphaComponent(0.6)
        overlay.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        let scanRect = CGRect(x: bounds.width * scanAreaRatio.origin.x, y: bounds.height * scanAreaRatio.origin.y, width: bounds.width * scanAreaRatio.width, height: bounds.height * scanAreaRatio.height)
        let path = UIBezierPath(rect: overlay.bounds)
        let cutout = UIBezierPath(roundedRect: scanRect, cornerRadius: 16)
        path.append(cutout)
        path.usesEvenOddFillRule = true
        let mask = CAShapeLayer()
        mask.path = path.cgPath
        mask.fillRule = .evenOdd
        overlay.layer.mask = mask
        view.addSubview(overlay)
        let border = UIView(frame: scanRect)
        border.layer.borderWidth = 3
        border.layer.borderColor = UIColor.systemGreen.cgColor
        border.layer.cornerRadius = 16
        border.autoresizingMask = [.flexibleLeftMargin, .flexibleRightMargin, .flexibleTopMargin, .flexibleBottomMargin]
        view.addSubview(border)
        let hintLabel = UILabel()
        hintLabel.text = "Наведите камеру на штрихкод"
        hintLabel.textColor = .white
        hintLabel.font = .systemFont(ofSize: 16, weight: .medium)
        hintLabel.textAlignment = .center
        hintLabel.frame = CGRect(x: 0, y: scanRect.maxY + 20, width: bounds.width, height: 30)
        hintLabel.autoresizingMask = [.flexibleWidth, .flexibleTopMargin]
        view.addSubview(hintLabel)
        let cancelButton = UIButton(type: .system)
        cancelButton.setTitle("Отмена", for: .normal)
        cancelButton.titleLabel?.font = .systemFont(ofSize: 17, weight: .semibold)
        cancelButton.setTitleColor(.white, for: .normal)
        cancelButton.frame = CGRect(x: 20, y: bounds.height - 80, width: 100, height: 44)
        cancelButton.addTarget(self, action: #selector(cancelTapped), for: .touchUpInside)
        view.addSubview(cancelButton)
    }

    @objc private func cancelTapped() { onCancelTapped?() }

    func metadataOutput(_ output: AVCaptureMetadataOutput, didOutput metadataObjects: [AVMetadataObject], from connection: AVCaptureConnection) {
        guard !isScanning else { return }
        if let metadataObject = metadataObjects.first as? AVMetadataMachineReadableCodeObject,
           let stringValue = metadataObject.stringValue {
            isScanning = true
            captureSession.stopRunning()
            AudioServicesPlaySystemSound(1057)
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.3) { [weak self] in
                self?.onCodeScanned?(stringValue)
            }
        }
    }

    private func showAlert(_ title: String, _ message: String) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default) { [weak self] _ in self?.dismiss(animated: true) })
        present(alert, animated: true)
    }
}
