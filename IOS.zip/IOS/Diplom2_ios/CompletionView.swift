import SwiftUI

struct CompletionView: View {
    let orderID: String
    let progress: Double
    let onComplete: () -> Void

    var body: some View {
        VStack(spacing: 30) {
            Image(systemName: "checkmark.seal.fill").font(.system(size: 80)).foregroundColor(.green)
            Text("Заказ \(orderID) выполнен!").font(.title).bold()
            Text("Все позиции успешно отсканированы").font(.subheadline).foregroundColor(.secondary)
            VStack(alignment: .leading, spacing: 10) {
                HStack { Text("Прогресс:"); Spacer(); Text("\(Int(progress * 100))%").bold() }
                HStack { Text("Статус:"); Spacer(); Text("Готов").foregroundColor(.green).bold() }
            }
            .padding()
            .background(Color.gray.opacity(0.1))
            .cornerRadius(12)
            Button(action: { onComplete() }) {
                Text("Завершить заказ").fontWeight(.bold).frame(maxWidth: .infinity).padding(.vertical, 14)
            }
            .buttonStyle(.borderedProminent).tint(.green)
            Spacer()
        }
        .padding()
        .interactiveDismissDisabled()
    }
}
