import SwiftUI

@main
struct Diplom2App: App {
    @StateObject private var authManager = AuthManager()

    var body: some Scene {
        WindowGroup {
            ContentView().environmentObject(authManager).preferredColorScheme(.light)
        }
    }
}

struct ContentView: View {
    @EnvironmentObject var authManager: AuthManager

    var body: some View {
        Group {
            if authManager.isLoggedIn { OrdersListView() } else { LoginView() }
        }
    }
}
