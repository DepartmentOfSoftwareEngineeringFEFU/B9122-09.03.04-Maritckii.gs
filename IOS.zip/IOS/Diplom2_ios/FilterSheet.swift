import SwiftUI

struct FilterSheet: View {
    @Binding var selectedStatus: String?
    let allStatuses: [String]
    @Environment(\.dismiss) var dismiss

    var body: some View {
        NavigationStack {
            List {
                Section("Статус заказа") {
                    ForEach(["Все"] + allStatuses, id: \.self) { status in
                        HStack {
                            Text(status == "Все" ? "Все статусы" : status.capitalized)
                            Spacer()
                            if (status == "Все" && selectedStatus == nil) || (status != "Все" && selectedStatus == status) {
                                Image(systemName: "checkmark").foregroundColor(.blue)
                            }
                        }
                        .contentShape(Rectangle())
                        .onTapGesture { selectedStatus = status == "Все" ? nil : status }
                    }
                }
            }
            .navigationTitle("Фильтр")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("Сбросить") { selectedStatus = nil } }
                ToolbarItem(placement: .confirmationAction) { Button("Готово") { dismiss() } }
            }
        }
    }
}
