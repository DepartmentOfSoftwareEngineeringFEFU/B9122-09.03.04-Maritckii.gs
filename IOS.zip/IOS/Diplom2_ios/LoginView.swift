import SwiftUI

struct LoginView: View {
    @EnvironmentObject var authManager: AuthManager
    @State private var login = ""
    @State private var password = ""
    @State private var errorMessage = ""
    @State private var isLoading = false

    var body: some View {
        NavigationStack {
            VStack(spacing: 24) {
                Spacer()
                VStack(spacing: 12) {
                    Image(systemName: "shippingbox.fill").font(.system(size: 70)).foregroundColor(.blue)
                    Text("mar_Склад").font(.largeTitle).fontWeight(.bold)
                    Text("Система автоматизации склада").font(.subheadline).foregroundColor(.secondary)
                }
                .padding(.top, 40)
                Spacer()
                VStack(spacing: 16) {
                    VStack(alignment: .leading, spacing: 6) {
                        Text("Логин").font(.caption).foregroundColor(.secondary)
                        TextField("Введите логин", text: $login).textFieldStyle(PlainTextFieldStyle()).padding().background(Color(.systemGray6)).cornerRadius(10).autocapitalization(.none).disableAutocorrection(true)
                    }
                    VStack(alignment: .leading, spacing: 6) {
                        Text("Пароль").font(.caption).foregroundColor(.secondary)
                        SecureField("Введите пароль", text: $password).textFieldStyle(PlainTextFieldStyle()).padding().background(Color(.systemGray6)).cornerRadius(10)
                    }
                    if !errorMessage.isEmpty {
                        HStack {
                            Image(systemName: "exclamationmark.circle.fill").foregroundColor(.red)
                            Text(errorMessage).font(.caption).foregroundColor(.red)
                        }
                        .padding(.horizontal)
                    }
                }
                .padding(.horizontal, 32)
                Button(action: performLogin) {
                    HStack {
                        if isLoading { ProgressView().tint(.white) } else { Text("Войти в систему").fontWeight(.semibold) }
                    }
                    .frame(maxWidth: .infinity).padding(.vertical, 14).background(Color.blue).foregroundColor(.white).cornerRadius(12)
                }
                .disabled(login.isEmpty || password.isEmpty || isLoading)
                .padding(.horizontal, 32)
                Spacer()
                Text("Версия 1.1.1").font(.caption2).foregroundColor(.secondary).padding(.bottom, 20)
            }
            .navigationTitle("")
            .navigationBarTitleDisplayMode(.large)
        }
    }

    private func performLogin() {
        isLoading = true
        errorMessage = ""
        Task {
            do {
                let res = try await APIClient.shared.login(login: login, password: password)
                await MainActor.run {
                    UserDefaults.standard.set(res.accessToken, forKey: "jwt_token")
                    authManager.setToken(res.accessToken)
                    isLoading = false
                }
            } catch {
                await MainActor.run {
                    errorMessage = "Неверный логин или пароль: \(error.localizedDescription)"
                    isLoading = false
                }
            }
        }
    }
}

#Preview { LoginView().environmentObject(AuthManager()) }
