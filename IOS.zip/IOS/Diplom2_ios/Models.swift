import Foundation

struct LoginRequest: Codable {
    let login: String
    let password: String
}

struct TokenResponse: Codable {
    let accessToken: String
    let tokenType: String
    enum CodingKeys: String, CodingKey {
        case accessToken = "access_token"
        case tokenType = "token_type"
    }
}

struct OrderSummary: Identifiable, Codable {
    let id: String
    let totalTimeSec: Double?
    let totalDistanceM: Double?
    let status: String
    let createdAt: String?
    enum CodingKeys: String, CodingKey {
        case id = "order_id"
        case totalTimeSec = "total_time_sec"
        case totalDistanceM = "total_distance_m"
        case status
        case createdAt = "created_at"
    }
}

struct OrderItem: Identifiable, Codable {
    var id: String { materialID }
    let materialID: String
    let name: String
    let rack: String
    let warehouse: String
    let weight: String
    let height: String
    let width: String
    let depth: String
    let qty: Int
    enum CodingKeys: String, CodingKey {
        case materialID = "material_id"
        case name, rack, warehouse, weight, height, width, depth, qty
    }
}

struct OrderDetails: Codable {
    let orderID: String
    let items: [OrderItem]
    let status: String
    let progress: Double
    let scannedMaterials: [String]
    enum CodingKeys: String, CodingKey {
        case orderID = "order_id"
        case items, status, progress
        case scannedMaterials = "scanned_materials"
    }
    init(orderID: String, items: [OrderItem], status: String, progress: Double, scannedMaterials: [String] = []) {
        self.orderID = orderID
        self.items = items
        self.status = status
        self.progress = progress
        self.scannedMaterials = scannedMaterials
    }
}

struct RouteStep: Identifiable, Codable {
    let id: Int
    let from: String
    let to: String
    let timeSec: Double
    let distM: Double
    let cumDistM: Double
    enum CodingKeys: String, CodingKey {
        case id = "step"
        case from = "from_"
        case to
        case timeSec = "time_sec"
        case distM = "dist_m"
        case cumDistM = "cum_dist_m"
    }
}

struct RouteSegmentImage: Identifiable, Codable {
    var id: String { name }
    let name: String
    let pngURL: String
    enum CodingKeys: String, CodingKey {
        case name
        case pngURL = "png_url"
    }
}

struct RouteResponse: Codable {
    let orderID: String
    let totalTimeSec: Double
    let totalDistanceM: Double
    let steps: [RouteStep]
    let segments: [RouteSegmentImage]
    let fullPngURL: String
    let mapWarning: String?
    enum CodingKeys: String, CodingKey {
        case orderID = "order_id"
        case totalTimeSec = "total_time_sec"
        case totalDistanceM = "total_distance_m"
        case steps, segments
        case fullPngURL = "full_png_url"
        case mapWarning = "map_warning"
    }
}

struct ScanEvent: Codable {
    let orderID: String
    let workerID: String
    let timestamp: String
    let barcode: String
    enum CodingKeys: String, CodingKey {
        case orderID = "order_id"
        case workerID = "worker_id"
        case timestamp, barcode
    }
}

struct ScanResponse: Codable {
    let status: String
    let message: String
    let progress: Double
    let materialName: String?
    enum CodingKeys: String, CodingKey {
        case status, message, progress
        case materialName = "material_name"
    }
}
