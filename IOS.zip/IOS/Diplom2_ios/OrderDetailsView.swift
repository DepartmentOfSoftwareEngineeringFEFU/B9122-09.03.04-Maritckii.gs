import SwiftUI
import AVFoundation

struct OrderDetailsView: View {
    let orderID: String
    @StateObject private var vm: OrderDetailsViewModel
    @State private var showScanner = false
    @State private var showCompletion = false
    @State private var feedbackColor: Color? = nil
    @State private var feedbackMessage = ""

    init(orderID: String) {
        self.orderID = orderID
        _vm = StateObject(wrappedValue: OrderDetailsViewModel(orderID: orderID))
    }

    var isCompleted: Bool {
        return vm.details?.status == "completed" || vm.progress >= 1.0
    }

    var body: some View {
        ZStack {
            if let details = vm.details {
                List {
                    Section("Позиции заказа") {
                        ForEach(details.items) { item in
                            HStack(alignment: .top, spacing: 8) {
                                let isPicked = vm.pickedMaterialIDs.contains(item.materialID)
                                Image(systemName: isPicked ? "checkmark.circle.fill" : "circle")
                                    .foregroundColor(isPicked ? .green : .gray)
                                    .padding(.top, 4)
                                    .onTapGesture {
                                        if vm.isAccepted && !isCompleted {
                                            vm.togglePicked(materialID: item.materialID)
                                        }
                                    }
                                VStack(alignment: .leading, spacing: 4) {
                                    Text("\(item.materialID) — \(item.name)").font(.headline)
                                    Text("Стеллаж \(item.rack), склад \(item.warehouse)").font(.caption)
                                    Text("Кол-во: \(item.qty)").font(.caption2).foregroundColor(.gray)
                                    Text("Вес: \(item.weight) кг").font(.caption2)
                                    Text("Габариты: \(item.height) x \(item.width) x \(item.depth) м").font(.caption2)
                                }
                            }
                            .padding(.vertical, 4)
                        }
                    }

                    if vm.isAccepted && !isCompleted, let route = vm.route {
                        Section("Маршрут 2D") {
                            if let warning = route.mapWarning, !warning.isEmpty {
                                HStack {
                                    Image(systemName: "exclamationmark.triangle.fill").foregroundColor(.orange)
                                    Text(warning).font(.caption).foregroundColor(.orange)
                                }
                                .padding(.vertical, 4)
                            }
                            if !route.fullPngURL.isEmpty, let url = vm.fullRouteImageURL {
                                AsyncImage(url: url) { phase in
                                    switch phase {
                                    case .empty: ProgressView("Загрузка карты…").frame(maxWidth: .infinity, minHeight: 200)
                                    case .success(let image): image.resizable().scaledToFit()
                                    case .failure: Text("Карта недоступна").foregroundColor(.gray)
                                    @unknown default: EmptyView()
                                    }
                                }
                            }
                        }

                        if !route.steps.isEmpty {
                            Section("Шаги маршрута (\(route.steps.count))") {
                                ForEach(route.steps) { step in
                                    VStack(alignment: .leading, spacing: 6) {
                                        HStack {
                                            Image(systemName: step.id == 1 ? "flag.checkered" : "arrow.right")
                                                .foregroundColor(step.id == 1 ? .green : .blue)
                                                .font(.system(size: 16, weight: .bold))
                                                .frame(width: 24)
                                            VStack(alignment: .leading, spacing: 2) {
                                                Text("Шаг \(step.id)").font(.subheadline).fontWeight(.semibold)
                                                Text("\(step.from) → \(step.to)").font(.caption).foregroundColor(.primary)
                                            }
                                            Spacer()
                                            VStack(alignment: .trailing, spacing: 2) {
                                                Text(String(format: "%.0f с", step.timeSec)).font(.caption).fontWeight(.medium).foregroundColor(.blue)
                                                Text(String(format: "%.1f м", step.distM)).font(.caption2).foregroundColor(.gray)
                                            }
                                        }
                                        if route.totalDistanceM > 0 {
                                            GeometryReader { geo in
                                                ZStack(alignment: .leading) {
                                                    RoundedRectangle(cornerRadius: 2).fill(Color.gray.opacity(0.2)).frame(height: 4)
                                                    RoundedRectangle(cornerRadius: 2).fill(Color.blue.opacity(0.6)).frame(width: geo.size.width * CGFloat(step.cumDistM / route.totalDistanceM), height: 4)
                                                }
                                            }
                                            .frame(height: 4)
                                            HStack {
                                                Text("Накоплено: \(String(format: "%.1f", step.cumDistM)) м").font(.caption2).foregroundColor(.gray)
                                                Spacer()
                                            }
                                        }
                                    }
                                    .padding(.vertical, 4)
                                }
                            }
                        }

                        Section("Итого") {
                            HStack { Text("Общее время:"); Spacer(); Text(String(format: "%.0f с", route.totalTimeSec)).bold() }
                            HStack { Text("Общее расстояние:"); Spacer(); Text(String(format: "%.1f м", route.totalDistanceM)).bold() }
                        }
                    }

                    Section("Прогресс") {
                        ProgressView(value: vm.progress) {
                            Text("Выполнено: \(Int(vm.progress * 100))%")
                        }
                        .progressViewStyle(LinearProgressViewStyle(tint: isCompleted ? .green : .blue))
                    }

                    if let info = vm.lastScanInfo {
                        Section("Последний скан") {
                            Text(info).font(.caption).foregroundColor(.blue)
                        }
                    }
                }
                .navigationTitle("Заказ \(vm.orderID)")
                .navigationBarTitleDisplayMode(.inline)
                .toolbar {
                    ToolbarItem(placement: .bottomBar) {
                        if isCompleted {
                            if vm.details?.status != "completed" {
                                Button(action: { showCompletion = true }) {
                                    Text("Завершить заказ").fontWeight(.bold).frame(maxWidth: .infinity).padding(.vertical, 12)
                                }
                                .buttonStyle(.borderedProminent).tint(.green)
                            } else { EmptyView() }
                        } else if !vm.isAccepted {
                            Button(action: { vm.acceptOrder() }) {
                                Text("Принять заказ").fontWeight(.semibold).frame(maxWidth: .infinity).padding(.vertical, 12)
                            }
                            .buttonStyle(.borderedProminent).tint(.blue)
                        } else {
                            HStack(spacing: 16) {
                                Button(action: { Task { await vm.buildRoute() } }) {
                                    HStack { Image(systemName: "map"); Text("Маршрут") }
                                        .fontWeight(.semibold).frame(maxWidth: .infinity).padding(.vertical, 12)
                                }
                                .buttonStyle(.borderedProminent).tint(.blue)
                                if vm.route != nil {
                                    Button(action: { showScanner = true }) {
                                        HStack { Image(systemName: "barcode.viewfinder"); Text("Сканировать") }
                                            .fontWeight(.semibold).frame(maxWidth: .infinity).padding(.vertical, 12)
                                    }
                                    .buttonStyle(.borderedProminent).tint(.green)
                                }
                            }
                        }
                    }
                }
            } else if vm.isLoading {
                ProgressView("Загрузка…")
            } else if let err = vm.error {
                VStack(spacing: 16) {
                    Image(systemName: "exclamationmark.triangle.fill").font(.system(size: 50)).foregroundColor(.red)
                    Text("Ошибка: \(err)").foregroundColor(.red)
                    Button("Повторить") { Task { await vm.loadDetails() } }.buttonStyle(.borderedProminent)
                }
                .padding()
            }

            if let color = feedbackColor {
                VStack {
                    Spacer()
                    HStack(spacing: 12) {
                        Image(systemName: color == .green ? "checkmark.circle.fill" : "xmark.circle.fill")
                            .font(.system(size: 28)).foregroundColor(.white)
                        Text(feedbackMessage)
                            .font(.system(size: 17, weight: .semibold)).foregroundColor(.white)
                            .lineLimit(2).minimumScaleFactor(0.8)
                        Spacer()
                    }
                    .padding(.horizontal, 20).padding(.vertical, 16)
                    .background(RoundedRectangle(cornerRadius: 16).fill(color.opacity(0.85)))
                    .padding(.horizontal, 20).padding(.bottom, 100)
                }
                .zIndex(1)
            }
        }
        .task { await vm.loadDetails() }
        .sheet(isPresented: $showScanner) {
            BarcodeScannerView { code in
                showScanner = false
                Task { await handleScan(barcode: code) }
            } onCancel: { showScanner = false }
        }
        .fullScreenCover(isPresented: $showCompletion) {
            CompletionView(orderID: orderID, progress: vm.progress, onComplete: {
                vm.completeOrder()
                showCompletion = false
            })
        }
    }

    private func handleScan(barcode: String) async {
        guard let response = await vm.verifyScan(barcode: barcode) else {
            await showFeedback(color: .red, message: "Ошибка сети")
            triggerHaptic(success: false)
            return
        }
        if response.status == "success" || response.status == "completed" {
            await showFeedback(color: .green, message: response.message)
            triggerHaptic(success: true)
        } else {
            await showFeedback(color: .red, message: response.message)
            triggerHaptic(success: false)
        }
    }

    private func showFeedback(color: Color, message: String) async {
        await MainActor.run { self.feedbackColor = color; self.feedbackMessage = message }
        try? await Task.sleep(nanoseconds: 1_500_000_000)
        await MainActor.run { self.feedbackColor = nil }
    }

    private func triggerHaptic(success: Bool) {
        let generator = UINotificationFeedbackGenerator()
        generator.notificationOccurred(success ? .success : .error)
        AudioServicesPlaySystemSound(success ? 1057 : 1053)
    }
}

#Preview {
    NavigationStack { OrderDetailsView(orderID: "000000066") }
}
