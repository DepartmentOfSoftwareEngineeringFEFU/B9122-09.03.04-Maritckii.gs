import Foundation
import Combine
import AVFoundation

@MainActor
final class OrderDetailsViewModel: ObservableObject {
    @Published var details: OrderDetails?
    @Published var route: RouteResponse?
    @Published var isLoading = false
    @Published var error: String?
    @Published var lastScanInfo: String?
    @Published var isAccepted: Bool = false
    @Published var pickedMaterialIDs: Set<String> = []
    @Published var progress: Double = 0.0
    let orderID: String

    init(orderID: String) { self.orderID = orderID }

    func loadDetails() async {
        isLoading = true
        error = nil
        defer { isLoading = false }
        do {
            let d = try await APIClient.shared.fetchOrderDetails(orderID: orderID)
            details = d
            isAccepted = (d.status == "accepted" || d.status == "in_progress")
            progress = d.progress
            pickedMaterialIDs = Set(d.scannedMaterials)
            if d.status == "completed" {
                isAccepted = false
                progress = 1.0
                pickedMaterialIDs = Set(d.items.map { $0.materialID })
            }
        } catch {
            self.error = error.localizedDescription
        }
    }

    func buildRoute() async {
        isLoading = true
        error = nil
        defer { isLoading = false }
        do {
            route = try await APIClient.shared.buildRoute(orderID: orderID)
        } catch {
            self.error = error.localizedDescription
        }
    }

    func acceptOrder() {
        Task {
            do {
                try await APIClient.shared.updateOrderStatus(orderID: orderID, status: "accepted")
                await MainActor.run {
                    self.isAccepted = true
                    if let d = self.details {
                        self.details = OrderDetails(orderID: d.orderID, items: d.items, status: "accepted", progress: d.progress)
                    }
                }
            } catch {
                await MainActor.run { self.error = error.localizedDescription }
            }
        }
    }

    func completeOrder() {
        Task {
            do {
                try await APIClient.shared.updateOrderStatus(orderID: orderID, status: "completed")
                await MainActor.run {
                    if let d = self.details {
                        self.details = OrderDetails(orderID: d.orderID, items: d.items, status: "completed", progress: 1.0)
                    }
                    self.progress = 1.0
                }
            } catch {
                await MainActor.run { self.error = error.localizedDescription }
            }
        }
    }

    func togglePicked(materialID: String) {
        if pickedMaterialIDs.contains(materialID) {
            pickedMaterialIDs.remove(materialID)
        } else {
            pickedMaterialIDs.insert(materialID)
        }
    }

    func verifyScan(barcode: String) async -> ScanResponse? {
        guard let details = details else { return nil }
        do {
            let response = try await APIClient.shared.verifyScan(orderID: details.orderID, barcode: barcode)
            await MainActor.run {
                lastScanInfo = "Скан: \(barcode) — \(response.message)"
                progress = response.progress
                if response.status == "success" || response.status == "completed" {
                    if let materialName = response.materialName {
                        for item in details.items {
                            if item.name == materialName || item.materialID == barcode {
                                pickedMaterialIDs.insert(item.materialID)
                                break
                            }
                        }
                    }
                }
            }
            return response
        } catch {
            await MainActor.run { lastScanInfo = "Ошибка: \(error.localizedDescription)" }
            return nil
        }
    }

    var fullRouteImageURL: URL? {
        guard let route = route else { return nil }
        let path = route.fullPngURL.hasPrefix("/") ? String(route.fullPngURL.dropFirst()) : route.fullPngURL
        return APIClient.shared.baseURL.appendingPathComponent(path)
    }
}
