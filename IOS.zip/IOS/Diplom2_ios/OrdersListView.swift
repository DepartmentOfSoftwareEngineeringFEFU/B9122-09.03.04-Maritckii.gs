import SwiftUI
import Combine

@MainActor
class OrdersListViewModel: ObservableObject {
    @Published var orders: [OrderSummary] = []
    @Published var isLoading = false
    @Published var error: String?
    @Published var searchTerm = ""
    @Published var selectedStatus: String? = nil
    let allStatuses = ["new", "accepted", "in_progress", "completed"]

    var filteredOrders: [OrderSummary] {
        orders.filter { order in
            let matchesSearch = searchTerm.isEmpty || order.id.localizedCaseInsensitiveContains(searchTerm)
            let matchesStatus = selectedStatus == nil || order.status == selectedStatus
            return matchesSearch && matchesStatus
        }
    }

    func load() async {
        isLoading = true
        error = nil
        do {
            let fetched = try await APIClient.shared.fetchOrders()
            orders = fetched.sorted { $0.id < $1.id }
        } catch {
            self.error = error.localizedDescription
        }
        isLoading = false
    }
}

struct OrdersListView: View {
    @StateObject private var vm = OrdersListViewModel()
    @EnvironmentObject var authManager: AuthManager
    @State private var isFilterSheetPresented = false

    var body: some View {
        NavigationStack {
            Group {
                if vm.isLoading && vm.orders.isEmpty {
                    ProgressView("Загрузка заказов…")
                } else if let err = vm.error {
                    Text("Ошибка: \(err)").foregroundColor(.red).padding()
                } else {
                    List(vm.filteredOrders) { order in
                        NavigationLink(destination: OrderDetailsView(orderID: order.id)) {
                            VStack(alignment: .leading, spacing: 4) {
                                Text("Заказ \(order.id)").font(.headline)
                                Text("Статус: \(order.status)").font(.caption).foregroundColor(.gray)
                            }
                            .padding(.vertical, 4)
                        }
                    }
                    .refreshable { await vm.load() }
                    .searchable(text: $vm.searchTerm, prompt: "Поиск по номеру...")
                }
            }
            .navigationTitle("Заказы")
            .toolbar {
                ToolbarItemGroup(placement: .topBarTrailing) {
                    Button { isFilterSheetPresented = true } label: {
                        Image(systemName: "line.3.horizontal.decrease.circle")
                    }
                    Button { authManager.logout() } label: {
                        Image(systemName: "rectangle.portrait.and.arrow.right")
                    }
                }
            }
            .sheet(isPresented: $isFilterSheetPresented) {
                FilterSheet(selectedStatus: $vm.selectedStatus, allStatuses: vm.allStatuses)
            }
            .task { await vm.load() }
        }
    }
}

#Preview { OrdersListView().environmentObject(AuthManager()) }
